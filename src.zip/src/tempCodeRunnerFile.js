import AddVoter from './AddVoter';
// import VotingSection from './VotingSection';
// import Result from './Result';